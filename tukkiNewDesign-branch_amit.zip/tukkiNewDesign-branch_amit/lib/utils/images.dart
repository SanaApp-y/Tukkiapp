class Images {
  static const String logo = 'assets/images/applogo.png';
  static const String welc_logo = 'assets/images/logo.png';
  static const String welcome_info = 'assets/images/welcomeInfo.png';
  static const String logogif = 'assets/images/darktextgif.gif';
  static const String splash_image = 'assets/images/spleshimage.png';
  static const String banner_1 = 'assets/images/image 2.png';
  static const String banner_2 = 'assets/images/image 3.png';
  static const String banner_3 = 'assets/images/image 4.png';
  static const String spleshscreen_phone = 'assets/images/phone.png';
  static const String login_back = 'assets/images/back.png';
  static const String show_password = 'assets/images/showpassowrd.png';
  static const String hide_password = 'assets/images/HidePassword.png';
  static const String Unlock = 'assets/images/Unlock.png';
  static const String google = 'assets/images/google.png';
  static const String facebook = 'assets/images/facebook.png';
  static const String user = 'assets/images/user.png';
  static const String email = 'assets/images/email.png';
  static const String location = 'assets/images/location.jpg';
  static const String Profile = 'assets/images/profile-default.png';
  static const String Notification = 'assets/images/Notification.png';
  static const String Search = 'assets/images/SearchHomescreen.png';
}
