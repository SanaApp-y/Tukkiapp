class text{
  static const String title = "Tukki";
  static const String discription = "Manage your properties with ease and \nget instant alert about responses";

  text(String s);
}