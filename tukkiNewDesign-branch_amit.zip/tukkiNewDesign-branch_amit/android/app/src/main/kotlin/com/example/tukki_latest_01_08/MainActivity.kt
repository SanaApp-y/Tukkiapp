package com.example.tukki_latest_01_08

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
